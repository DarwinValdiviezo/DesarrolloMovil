import 'package:flutter/material.dart';
import '../logica/gasolinera.dart';

class Ejercicio1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 1 - Gasolinera',
            style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.orange,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Gasolinera(),
      ),
    );
  }
}
