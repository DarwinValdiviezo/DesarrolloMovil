import 'package:flutter/material.dart';
import 'ejercicio1.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Prueba 1 Parcial 1', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.green,
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Image.asset(
            'assets/images/primax.png',
            height: 500,
            fit: BoxFit.cover,
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(16.0),
              children: [
                ListTile(
                  leading: Icon(Icons.local_gas_station, color: Colors.green),
                  title: Text('Ejercicio 1 - Gasolinera'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Ejercicio1()),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
