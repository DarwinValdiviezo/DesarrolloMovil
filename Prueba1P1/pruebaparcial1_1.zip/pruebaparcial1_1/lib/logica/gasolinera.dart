import 'package:flutter/material.dart';

class Gasolinera extends StatefulWidget {
  @override
  _GasolineraState createState() => _GasolineraState();
}

class _GasolineraState extends State<Gasolinera> {
  final TextEditingController _galonesController = TextEditingController();
  String _tipoGasolina = 'extra';
  double _totalAPagar = 0.0;

  // Precios por litro en Ecuador
  final Map<String, double> _preciosPorLitro = {
    'extra': 2.679,
    'super': 3.49,
  };
//reiniciar el valor
  void _calcularCosto() {
    final galones = double.tryParse(_galonesController.text);

    if (galones == null || galones <= 0) {
      setState(() {
        _totalAPagar = 0.0;
      });
      return;
    }

    // convertir de galones a litros
    final litros = galones * 3.78541;
    final precioPorLitro = _preciosPorLitro[_tipoGasolina]!;
    setState(() {
      _totalAPagar = litros * precioPorLitro;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          DropdownButton<String>(
            value: _tipoGasolina,
            items: [
              DropdownMenuItem(value: 'extra', child: Text('Extra')),
              DropdownMenuItem(value: 'super', child: Text('Súper')),
            ],
            onChanged: (value) {
              setState(() {
                _tipoGasolina = value!;
              });
            },
          ),
          TextField(
            controller: _galonesController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Galones'),
          ),
          ElevatedButton(
            onPressed: _calcularCosto,
            child: Text('Calcular Costo en Litros'),
          ),
          if (_totalAPagar > 0)
            Text(
              'Total: \$${_totalAPagar.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
        ],
      ),
    );
  }
}
