package com.example.pruebaparcial1_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
