import 'package:flutter/material.dart';
import 'package:tarea1/screens/ejercicio1_screen.dart';
import 'package:tarea1/screens/ejercicio2_screen.dart';
import 'package:tarea1/screens/ejercicio3_screen.dart';
import 'package:tarea1/screens/ejercicio5_screen.dart';
import 'package:tarea1/screens/ejercicio6_screen.dart';
import 'screens/main_screen.dart';
import 'screens/ejercicio4_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ejercicios Flutter',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainScreen(),
      debugShowCheckedModeBanner: false, // Oculta la etiqueta Debug
      routes: {
        '/ejercicio1': (context) => Ejercicio1Screen(),
        '/ejercicio2': (context) => Ejercicio2Screen(),
        '/ejercicio3': (context) => Ejercicio3Screen(),
        '/ejercicio4': (context) => Ejercicio4Screen(),
        '/ejercicio5': (context) => Ejercicio5Screen(),
        '/ejercicio6': (context) => Ejercicio6Screen(),
      },
    );
  }
}
