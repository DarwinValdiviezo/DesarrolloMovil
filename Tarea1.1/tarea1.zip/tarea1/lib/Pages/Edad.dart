import 'package:flutter/material.dart';

class Edad extends StatefulWidget {
  @override
  _EdadState createState() => _EdadState();
}

class _EdadState extends State<Edad> {
  final TextEditingController _ageController = TextEditingController();
  String _result = '';

  void _clasificarEdad() {
    final int? edad = int.tryParse(_ageController.text);
    if (edad == null || edad < 0) {
      setState(() {
        _result = 'Por favor, ingrese una edad válida.';
      });
      return;
    }

    if (edad <= 10) {
      _result = 'NIÑO';
    } else if (edad <= 14) {
      _result = 'PUBER';
    } else if (edad <= 18) {
      _result = 'ADOLESCENTE';
    } else if (edad <= 25) {
      _result = 'JOVEN';
    } else if (edad <= 65) {
      _result = 'ADULTO';
    } else {
      _result = 'ANCIANO';
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _ageController,
            decoration: InputDecoration(labelText: 'Ingrese la edad'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _clasificarEdad,
            child: Text('Clasificar'),
          ),
          SizedBox(height: 16),
          Text(_result, style: TextStyle(fontSize: 24)),
        ],
      ),
    );
  }
}
