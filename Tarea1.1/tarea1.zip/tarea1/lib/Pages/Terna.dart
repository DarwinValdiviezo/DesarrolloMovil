import 'package:flutter/material.dart';

class Terna extends StatefulWidget {
  @override
  _TernaState createState() => _TernaState();
}

class _TernaState extends State<Terna> {
  final TextEditingController aController = TextEditingController();
  final TextEditingController bController = TextEditingController();
  final TextEditingController cController = TextEditingController();
  String result = '';

  void checkPythagoreanTriple() {
    if (aController.text.isEmpty ||
        bController.text.isEmpty ||
        cController.text.isEmpty) {
      setState(() {
        result = 'Por favor, ingrese todos los valores.';
      });
      return;
    }

    int a = int.tryParse(aController.text) ?? 0;
    int b = int.tryParse(bController.text) ?? 0;
    int c = int.tryParse(cController.text) ?? 0;

    if (a <= 0 || b <= 0 || c <= 0) {
      setState(() {
        result = 'Todos los valores deben ser números positivos.';
      });
      return;
    }

    int aCuadrado = a * a;
    int bCuadrado = b * b;
    int cCuadrado = c * c;

    if (aCuadrado + bCuadrado == cCuadrado ||
        aCuadrado + cCuadrado == bCuadrado ||
        bCuadrado + cCuadrado == aCuadrado) {
      setState(() {
        result = "Es una terna pitagórica.";
      });
    } else {
      setState(() {
        result = "No es una terna pitagórica.";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: aController,
            decoration:
                const InputDecoration(labelText: 'Ingrese el valor de a'),
            keyboardType: TextInputType.number,
          ),
          TextField(
            controller: bController,
            decoration:
                const InputDecoration(labelText: 'Ingrese el valor de b'),
            keyboardType: TextInputType.number,
          ),
          TextField(
            controller: cController,
            decoration:
                const InputDecoration(labelText: 'Ingrese el valor de c'),
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: checkPythagoreanTriple,
            child: const Text('Verificar'),
          ),
          const SizedBox(height: 20),
          Text(result, style: const TextStyle(fontSize: 20)),
        ],
      ),
    );
  }
}
