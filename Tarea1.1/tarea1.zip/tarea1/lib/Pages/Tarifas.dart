import 'package:flutter/material.dart';

class Tarifas extends StatefulWidget {
  @override
  _TarifasState createState() => _TarifasState();
}

class _TarifasState extends State<Tarifas> {
  final TextEditingController _consumoController = TextEditingController();
  double _pagoConsumo = 0.0;
  double _iva = 0.0;
  double _totalPagar = 0.0;
  bool _mostrarTotal = false;
  String _mensajeError = '';

  void _calcularTarifa() {
    setState(() {
      _mostrarTotal = false; // Ocultar resultados previos al recalcular.
      _mensajeError = ''; // Limpiar mensajes de error.
    });

    // Validar entrada vacía.
    if (_consumoController.text.isEmpty) {
      setState(() {
        _mensajeError = 'Por favor, ingrese el consumo en KWH.';
      });
      return;
    }

    // Validar entrada como número positivo.
    int? consumo = int.tryParse(_consumoController.text);
    if (consumo == null || consumo <= 0) {
      setState(() {
        _mensajeError = 'Ingrese un valor numérico válido y mayor a 0.';
      });
      return;
    }

    // Calcular tarifa según los rangos de consumo.
    if (consumo <= 50) {
      _pagoConsumo = consumo * 30;
    } else if (consumo <= 100) {
      _pagoConsumo = (50 * 30) + ((consumo - 50) * 35);
    } else {
      _pagoConsumo = (50 * 30) + (50 * 35) + ((consumo - 100) * 42);
    }

    // Calcular IVA (15% del costo base).
    _iva = _pagoConsumo * 0.15;

    // Calcular total a pagar.
    _totalPagar = _pagoConsumo + _iva;
    setState(() {
      _mostrarTotal = true; // Mostrar los resultados si todo está correcto.
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _consumoController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Consumo (KWH)',
              border: OutlineInputBorder(),
              errorText: _mensajeError.isNotEmpty ? _mensajeError : null,
            ),
          ),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: _calcularTarifa,
            child: Text('Calcular'),
          ),
          SizedBox(height: 16.0),
          if (_mostrarTotal) ...[
            Text('Pago por consumo: \$${_pagoConsumo.toStringAsFixed(2)}'),
            Text('IVA (15%): \$${_iva.toStringAsFixed(2)}'),
            Text(
              'Total a pagar: \$${_totalPagar.toStringAsFixed(2)}',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ],
      ),
    );
  }
}
