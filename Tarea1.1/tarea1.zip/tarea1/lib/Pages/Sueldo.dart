import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Sueldo extends StatefulWidget {
  @override
  _SueldoState createState() => _SueldoState();
}

class _SueldoState extends State<Sueldo> {
  final _formKey = GlobalKey<FormState>();
  final _sueldoBaseController = TextEditingController();
  final _ventasController = TextEditingController();

  double? sueldoBase;
  double? ventas;
  double? comision;
  double? sueldoTotal;

  void _calcularSueldo() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        sueldoBase = double.parse(_sueldoBaseController.text);
        ventas = double.parse(_ventasController.text);
        comision = _calcularComision(ventas!);
        sueldoTotal = sueldoBase! + comision!;
      });
    }
  }

  double _calcularComision(double ventas) {
    if (ventas < 4000000) {
      return 0;
    } else if (ventas >= 4000000 && ventas < 10000000) {
      return ventas * 0.03;
    } else {
      return ventas * 0.07;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextFormField(
              controller: _sueldoBaseController,
              decoration: const InputDecoration(
                labelText: 'Sueldo Base',
                prefixText: '\$',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese el sueldo base';
                }
                if (double.parse(value) <= 0) {
                  return 'El sueldo base debe ser mayor a 0';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _ventasController,
              decoration: const InputDecoration(
                labelText: 'Monto de Ventas',
                prefixText: '\$',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese el monto de ventas';
                }
                if (double.parse(value) < 0) {
                  return 'Las ventas no pueden ser negativas';
                }
                return null;
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _calcularSueldo,
              child: const Text('Calcular Sueldo'),
            ),
            const SizedBox(height: 24),
            if (sueldoTotal != null) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Sueldo Base: \$${sueldoBase?.toStringAsFixed(2)}'),
                      Text('Ventas: \$${ventas?.toStringAsFixed(2)}'),
                      Text('Comisión: \$${comision?.toStringAsFixed(2)}'),
                      const Divider(),
                      Text(
                        'Sueldo Total: \$${sueldoTotal?.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _sueldoBaseController.dispose();
    _ventasController.dispose();
    super.dispose();
  }
}
