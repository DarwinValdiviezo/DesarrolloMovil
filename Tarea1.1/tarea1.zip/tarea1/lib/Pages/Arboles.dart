import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Arboles extends StatefulWidget {
  @override
  _ArbolesState createState() => _ArbolesState();
}

class _ArbolesState extends State<Arboles> {
  final _formKey = GlobalKey<FormState>();
  String _tipoArbol = 'Paltos';
  final _cantidadController = TextEditingController();
  double? _totalPagar;
  double? _subtotal;
  double? _rebajaAplicada;
  double? _subtotalConRebaja;
  double? _montoIVA;
  String? _detalleRebaja;

  final Map<String, double> _preciosUnitarios = {
    'Paltos': 1200,
    'Limones': 1000,
    'Chirimoyos': 980,
  };

  final Map<String, Map<String, double>> _rebajas = {
    'Paltos': {'normal': 0.10, 'mayor': 0.18},
    'Limones': {'normal': 0.125, 'mayor': 0.20},
    'Chirimoyos': {'normal': 0.145, 'mayor': 0.19},
  };

  void _calcularTotal() {
    if (_formKey.currentState!.validate()) {
      int cantidad = int.parse(_cantidadController.text);
      double precioUnitario = _preciosUnitarios[_tipoArbol]!;
      _subtotal = cantidad * precioUnitario;

      // Calcular rebaja
      double porcentajeRebaja;
      _detalleRebaja = '';

      if (cantidad <= 100) {
        porcentajeRebaja = 0;
        _detalleRebaja = 'Sin rebaja por cantidad menor a 100 árboles';
      } else if (cantidad <= 300) {
        porcentajeRebaja = _rebajas[_tipoArbol]!['normal']!;
        _detalleRebaja =
            'Rebaja del ${(porcentajeRebaja * 100).toStringAsFixed(1)}% por compra entre 100 y 300 árboles';
      } else {
        porcentajeRebaja = _rebajas[_tipoArbol]!['mayor']!;
        _detalleRebaja =
            'Rebaja del ${(porcentajeRebaja * 100).toStringAsFixed(1)}% por compra mayor a 300 árboles';
      }

      if (cantidad > 1000) {
        porcentajeRebaja += 0.15;
        _detalleRebaja =
            '$_detalleRebaja\nRebaja adicional del 15% por compra mayor a 1000 árboles';
      }

      _rebajaAplicada = _subtotal! * porcentajeRebaja;
      _subtotalConRebaja = _subtotal! - _rebajaAplicada!;

      // Calcular IVA (19%)
      _montoIVA = _subtotalConRebaja! * 0.19;
      _totalPagar = _subtotalConRebaja! + _montoIVA!;

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: _tipoArbol,
                decoration: const InputDecoration(
                  labelText: 'Tipo de Árbol',
                  border: OutlineInputBorder(),
                ),
                items: _preciosUnitarios.keys.map((String tipo) {
                  return DropdownMenuItem<String>(
                    value: tipo,
                    child: Text(tipo),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _tipoArbol = newValue!;
                  });
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _cantidadController,
                decoration: const InputDecoration(
                  labelText: 'Cantidad de árboles',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Por favor ingrese la cantidad';
                  }
                  if (int.parse(value) <= 0) {
                    return 'La cantidad debe ser mayor a 0';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _calcularTotal,
                child: const Text('Calcular Total'),
              ),
              const SizedBox(height: 24),
              if (_totalPagar != null) ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Resumen de la compra',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 16),
                        Text('Tipo de árbol: $_tipoArbol'),
                        Text('Cantidad: ${_cantidadController.text}'),
                        Text(
                            'Precio unitario: \$${_preciosUnitarios[_tipoArbol]!.toStringAsFixed(2)}'),
                        const Divider(),
                        Text('Subtotal: \$${_subtotal!.toStringAsFixed(2)}'),
                        if (_rebajaAplicada! > 0) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Detalles de la rebaja:',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(_detalleRebaja!),
                          Text(
                            'Monto rebajado: -\$${_rebajaAplicada!.toStringAsFixed(2)}',
                            style: const TextStyle(color: Colors.green),
                          ),
                          Text(
                            'Subtotal con rebaja: \$${_subtotalConRebaja!.toStringAsFixed(2)}',
                          ),
                        ],
                        const Divider(),
                        Text('IVA (19%): \$${_montoIVA!.toStringAsFixed(2)}'),
                        const SizedBox(height: 16),
                        Text(
                          'Total a pagar: \$${_totalPagar!.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _cantidadController.dispose();
    super.dispose();
  }
}
