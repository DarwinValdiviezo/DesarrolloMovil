import 'package:flutter/material.dart';

class Descuento extends StatefulWidget {
  @override
  _DescuentoState createState() => _DescuentoState();
}

class _DescuentoState extends State<Descuento> {
  final TextEditingController _cantidadController = TextEditingController();
  final TextEditingController _precioController = TextEditingController();
  String _resultado = '';

  void _calcularTotal() {
    final int? cantidad = int.tryParse(_cantidadController.text);
    final double? precio = double.tryParse(_precioController.text);

    if (cantidad == null || cantidad <= 0) {
      setState(() {
        _resultado = 'Ingrese una cantidad válida mayor a 0.';
      });
      return;
    }

    if (precio == null || precio <= 0) {
      setState(() {
        _resultado = 'Ingrese un precio válido mayor a 0.';
      });
      return;
    }

    int descuento;
    if (cantidad < 3) {
      descuento = 0;
    } else if (cantidad <= 5) {
      descuento = 10;
    } else {
      descuento = 20;
    }

    double total = cantidad * precio;
    double totalConDescuento = total - (total * descuento / 100);

    setState(() {
      _resultado = 'Total sin descuento: \$${total.toStringAsFixed(2)}\n'
          'Descuento aplicado: $descuento%\n'
          'Total a pagar: \$${totalConDescuento.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          TextField(
            controller: _cantidadController,
            decoration: InputDecoration(labelText: 'Cantidad de camisas'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16),
          TextField(
            controller: _precioController,
            decoration: InputDecoration(labelText: 'Precio por camisa'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _calcularTotal,
            child: Text('Calcular Total'),
          ),
          SizedBox(height: 16),
          Text(_resultado, style: TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}
