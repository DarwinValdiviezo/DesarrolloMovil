import 'package:flutter/material.dart';
import '../Pages/Sueldo.dart';

class Ejercicio5Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 5', style: TextStyle(color: Colors.white)),
        backgroundColor: Color(0xFF1B5E20), // Fondo verde oscuro
        centerTitle: true,
      ),
      backgroundColor: Color(0xFFE8F5E9), // Fondo verde claro
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Image.asset(
              'assets/images/dinero.png', // Imagen asociada al ejercicio
              height: 150, // Imagen más pequeña
              fit: BoxFit.contain,
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Color(0xFFC8E6C9), // Fondo verde suave
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Sueldo(),
            ),
          ),
        ],
      ),
    );
  }
}
