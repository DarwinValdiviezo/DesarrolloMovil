import 'package:flutter/material.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Menú Principal',
          style: TextStyle(
              color: Colors.white), // Cambia el texto del título a blanco
        ),
        backgroundColor: Color(0xFF1B5E20), // Verde oscuro elegante
        centerTitle: true,
      ),
      backgroundColor: Color(0xFFE8F5E9), // Verde claro suave para el fondo
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          // Ejercicio 1
          Card(
            color: Color(0xFFC8E6C9), // Verde pálido para resaltar cada tarjeta
            child: ListTile(
              leading: Icon(Icons.person,
                  color: Color(0xFF388E3C)), // Verde intermedio
              title: Text('Ejercicio 1: Clasificador de Edad'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio1');
              },
            ),
          ),

          // Ejercicio 2
          Card(
            color: Color(0xFFC8E6C9),
            child: ListTile(
              leading: Icon(Icons.shopping_bag, color: Color(0xFF2E7D32)),
              title: Text('Ejercicio 2: Descuento de Camisas'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio2');
              },
            ),
          ),

          // Ejercicio 3
          Card(
            color: Color(0xFFC8E6C9),
            child: ListTile(
              leading: Icon(Icons.calculate, color: Color(0xFF43A047)),
              title: Text('Ejercicio 3: Terna Pitagórica'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio3');
              },
            ),
          ),

          // Ejercicio 4
          Card(
            color: Color(0xFFC8E6C9),
            child: ListTile(
              leading: Icon(Icons.lightbulb, color: Color(0xFF4CAF50)),
              title: Text('Ejercicio 4: Tarifas Eléctricas'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio4');
              },
            ),
          ),

          // Ejercicio 5
          Card(
            color: Color(0xFFC8E6C9),
            child: ListTile(
              leading: Icon(Icons.attach_money, color: Color(0xFF66BB6A)),
              title: Text('Ejercicio 5: Cálculo de Sueldo'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio5');
              },
            ),
          ),

          // Ejercicio 6
          Card(
            color: Color(0xFFC8E6C9),
            child: ListTile(
              leading: Icon(Icons.nature, color: Color(0xFF81C784)),
              title: Text('Ejercicio 6: Venta de Árboles'),
              onTap: () {
                Navigator.pushNamed(context, '/ejercicio6');
              },
            ),
          ),
        ],
      ),
    );
  }
}
