import 'package:flutter/material.dart';
import '../Pages/Edad.dart';

class Ejercicio1Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 1', style: TextStyle(color: Colors.white)),
        backgroundColor: Color(0xFF1B5E20),
        centerTitle: true,
      ),
      backgroundColor: Color(0xFFE8F5E9),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Image.asset(
              'assets/images/edad.png',
              height: 150,
              fit: BoxFit.contain,
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Color(0xFFC8E6C9),
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Edad(),
            ),
          ),
        ],
      ),
    );
  }
}
